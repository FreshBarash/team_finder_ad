
import json
from django.http import JsonResponse
from django.shortcuts import get_object_or_404

def get_json_body(request):
    try:
        return json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return {}

def autocomplete_queryset(queryset, q):
    return queryset.filter(name__istartswith=q).order_by("name").values("id", "name")[:10]

def toggle_m2m(manager, obj):
    if manager.filter(pk=obj.pk).exists():
        manager.remove(obj)
        return False
    manager.add(obj)
    return True
