
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.db import models
from core.constants import MAX_ABOUT_LENGTH, MAX_PHONE_LENGTH, MAX_SKILL_NAME_LENGTH, MAX_USER_NAME_LENGTH

class UserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        user=self.model(email=self.normalize_email(email), **extra_fields)
        user.set_password(password)
        user.save()
        return user
    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email,password,**extra_fields)

class Skill(models.Model):
    name=models.CharField(max_length=MAX_SKILL_NAME_LENGTH, unique=True)
    def __str__(self): return self.name

class User(AbstractBaseUser, PermissionsMixin):
    email=models.EmailField(unique=True)
    name=models.CharField(max_length=MAX_USER_NAME_LENGTH)
    surname=models.CharField(max_length=MAX_USER_NAME_LENGTH)
    avatar=models.ImageField(upload_to='avatars/', default='avatars/default-avatar.png')
    phone=models.CharField(max_length=MAX_PHONE_LENGTH, blank=True)
    github_url=models.URLField(blank=True)
    about=models.TextField(max_length=MAX_ABOUT_LENGTH, blank=True)
    is_active=models.BooleanField(default=True)
    is_staff=models.BooleanField(default=False)
    skills=models.ManyToManyField(Skill, blank=True, related_name='users')
    USERNAME_FIELD='email'
    REQUIRED_FIELDS=['name','surname']
    objects=UserManager()
    def __str__(self): return self.email
