
from django.contrib.auth import login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from core.utils import autocomplete_queryset, get_json_body
from users.forms import LoginForm, ProfileForm, RegisterForm
from users.models import Skill, User

def participants_list(request):
    participants=User.objects.order_by('id')
    skill=request.GET.get('skill')
    if skill:
        participants=participants.filter(skills__id=skill)
    return render(request,'users/participants.html',{'participants':participants,'all_skills':Skill.objects.all(),'active_skill':skill})

def user_detail(request, id):
    user=get_object_or_404(User,id=id)
    return render(request,'users/user-details.html',{'user':user})

def register_view(request):
    form=RegisterForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        user=form.save(commit=False)
        user.set_password(form.cleaned_data['password'])
        user.save()
        login(request,user)
        return redirect('/projects/list/')
    return render(request,'users/register.html',{'form':form})

def login_view(request):
    form=LoginForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        login(request, form.user)
        return redirect('/projects/list/')
    return render(request,'users/login.html',{'form':form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('/projects/list/')

@login_required
def edit_profile(request):
    form=ProfileForm(request.POST or None, request.FILES or None, instance=request.user)
    if request.method=='POST' and form.is_valid():
        form.save()
        return redirect(f'/users/{request.user.id}/')
    return render(request,'users/edit_profile.html',{'form':form,'user':request.user})

@login_required
def change_password(request):
    form=PasswordChangeForm(request.user, request.POST or None)
    if request.method=='POST' and form.is_valid():
        user=form.save()
        update_session_auth_hash(request,user)
        return redirect(f'/users/{request.user.id}/')
    return render(request,'users/change_password.html',{'form':form})

def skills_autocomplete(request):
    q=request.GET.get('q','')
    return JsonResponse(list(autocomplete_queryset(Skill.objects.all(), q)), safe=False)

@login_required
def add_skill(request, id):
    if request.user.id != id:
        return JsonResponse({}, status=403)
    data=get_json_body(request)
    created=False
    if data.get('skill_id'):
        skill=get_object_or_404(Skill,id=data['skill_id'])
    else:
        skill, created=Skill.objects.get_or_create(name=data.get('name'))
    added=not request.user.skills.filter(id=skill.id).exists()
    if added:
        request.user.skills.add(skill)
    return JsonResponse({'skill_id':skill.id,'id':skill.id,'name':skill.name,'created':created,'added':added})

@login_required
def remove_skill(request,id,skill_id):
    if request.user.id != id:
        return JsonResponse({}, status=403)
    skill=get_object_or_404(Skill,id=skill_id)
    request.user.skills.remove(skill)
    return JsonResponse({'status':'ok'})
