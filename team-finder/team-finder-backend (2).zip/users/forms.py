
import re
from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import PasswordChangeForm
from users.models import User

class RegisterForm(forms.ModelForm):
    password=forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model=User
        fields=("name","surname","email","password")

class LoginForm(forms.Form):
    email=forms.EmailField()
    password=forms.CharField(widget=forms.PasswordInput)

    def clean(self):
        cleaned=super().clean()
        user=authenticate(email=cleaned.get("email"), password=cleaned.get("password"))
        if not user:
            raise forms.ValidationError("Неверный email или пароль")
        self.user=user
        return cleaned

class ProfileForm(forms.ModelForm):
    class Meta:
        model=User
        fields=("name","surname","avatar","about","phone","github_url")
