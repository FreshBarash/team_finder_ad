
from django.urls import path
from users import views
app_name='users'
urlpatterns=[
path('list/',views.participants_list,name='list'),
path('register/',views.register_view,name='register'),
path('login/',views.login_view,name='login'),
path('logout/',views.logout_view,name='logout'),
path('edit/',views.edit_profile,name='edit'),
path('change-password/',views.change_password,name='change_password'),
path('skills/',views.skills_autocomplete,name='skills'),
path('<int:id>/',views.user_detail,name='detail'),
path('<int:id>/skills/add/',views.add_skill,name='add_skill'),
path('<int:id>/skills/<int:skill_id>/remove/',views.remove_skill,name='remove_skill'),
]
