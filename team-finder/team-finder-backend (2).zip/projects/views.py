
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from core.constants import PROJECT_STATUS_CLOSED, PROJECT_STATUS_OPEN
from core.utils import get_json_body, toggle_m2m
from projects.forms import ProjectForm
from projects.models import Project

def project_list(request):
    projects=Project.objects.order_by('-created_at')
    return render(request,'projects/project_list.html',{'projects':projects})

def project_detail(request,id):
    project=get_object_or_404(Project,id=id)
    return render(request,'projects/project-details.html',{'project':project})

@login_required
def toggle_participate(request,id):
    project=get_object_or_404(Project,id=id)
    participant=toggle_m2m(project.participants, request.user)
    return JsonResponse({'status':'ok','participant':participant})

@login_required
def complete_project(request,id):
    project=get_object_or_404(Project,id=id,owner=request.user,status=PROJECT_STATUS_OPEN)
    project.status=PROJECT_STATUS_CLOSED
    project.save()
    return JsonResponse({'status':'ok','project_status':'closed'})

@login_required
def project_form(request,id=None):
    project=get_object_or_404(Project,id=id) if id else None
    form=ProjectForm(request.POST or None, instance=project)
    if request.method=='POST' and form.is_valid():
        obj=form.save(commit=False)
        if not project:
            obj.owner=request.user
        obj.save()
        if not project:
            obj.participants.add(request.user)
        return redirect(f'/projects/{obj.id}/')
    return render(request,'projects/create-project.html',{'form':form,'is_edit':bool(project)})
