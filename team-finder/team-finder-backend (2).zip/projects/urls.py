
from django.urls import path
from projects import views
app_name='projects'
urlpatterns=[
path('list/',views.project_list,name='list'),
path('create-project/',views.project_form,name='create'),
path('<int:id>/',views.project_detail,name='detail'),
path('<int:id>/edit/',views.project_form,name='edit'),
path('<int:id>/toggle-participate/',views.toggle_participate,name='toggle_participate'),
path('<int:id>/complete/',views.complete_project,name='complete'),
]
